# Current Champion State

## Public-proven champion
**V4 public = 0.95681**.

V4 is the strongest public-proven package because it produced a clear +0.00825 gain from only 16 targeted structural changes.

## Frozen working base
**V5** is still used as the frozen base for future residual experiments because:
- it adds only four `0→1` rescues;
- OOF/pseudo evidence was strong;
- public tie does not strongly falsify it due only four changes;
- private effect remains unknown.

For public certainty, V4 is the anchor. For private-oriented experimentation, V5 remains defensible.

## V6 status
No V6 variant should be submitted:
- V6A/B/D final predictions are equivalent to V5 or have zero active changes.
- V6C was not a valid/final submission candidate due generator/export issues.

## Current leader context
Observed Top-1 public: **0.98979**.

The project should not respond by mass-submitting. The next submission must come from a new validated information source.
