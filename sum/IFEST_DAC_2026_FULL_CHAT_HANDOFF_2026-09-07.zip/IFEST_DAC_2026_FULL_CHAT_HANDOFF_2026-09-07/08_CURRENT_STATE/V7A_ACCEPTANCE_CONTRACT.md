# V7A Acceptance Contract

V7A is promoted only if the following are satisfied without reopening the LOCK split.

## DESIGN gates
- 3-fold component-safe CV inside 80% DESIGN.
- DESIGN cross-fitted Macro F1 gain vs V5: **≥ +0.0015**.
- positive gain on at least **2 / 3 folds**.
- worst DESIGN fold gain: **> −0.0005**.
- held-out same-content canonical-vs-corrupted sequence-likelihood ranking: **≥90%**.
- selected coverage fraction: **>0**.

## LOCK gates
- LOCK Macro F1 gain vs frozen V5: **>0**.
- precision among selected LOCK `1→0` interventions: **≥50%**.
  - This is intentionally above the ~41.7% Macro-F1 break-even, not the old arbitrary 90% gate.
- component/bootstrap positive delta in **≥80%** of bootstrap replicates.

## Frozen-structure gates
- changes to V2/V4 locked structural decisions: **0**.
- changes to V5 rescue rows: **0**.

## Test deployment sanity
- final selected test changes roughly **5–90**.
- if 0 changes, do not submit; there is no new information.
- if intervention count is wildly outside the DESIGN-implied range, fail closed and inspect before submission.

## Failure policy
If LOCK fails:
- V7A is rejected.
- do not tune on LOCK.
- do not use public LB to rescue it.
- keep V4/V5 as champion/base.
