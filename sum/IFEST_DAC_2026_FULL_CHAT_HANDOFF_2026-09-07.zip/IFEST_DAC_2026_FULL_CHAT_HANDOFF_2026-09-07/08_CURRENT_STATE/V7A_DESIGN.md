# V7A — IndoBART Conditional Headline Likelihood Verifier

## Status
**Designed and approved. Not yet implemented/run in this chat.**

## Hypothesis
Because the article→positive-headline mapping is almost deterministic, a model trained to generate the canonical headline from the article should assign lower conditional likelihood / higher token surprisal to corrupted headlines.

This bypasses explicit challenger generation.

## Frozen hierarchy
1. V2 train-reference structural graph — LOCK.
2. V4 test-test canonical decisions — LOCK.
3. V5 positive rescues — LOCK.
4. V7A only operates on **V5-positive pure-fallback rows**.
5. V7A only makes **`1→0`** interventions.

## Backbone
Planned checkpoint:
- `indobenchmark/indobart-v2`
- ~132M parameters.

**Before use, verify the latest official pretrained-model rule.**

## Training data
### Positive generation examples
Use deduplicated positive article→headline mappings:
- approximately **11,153** distinct pairs.

Do not overweight exact duplicated positive structures.

### Real contrastive examples
Use same-content groups with one canonical positive and negative corrupted titles.

No external labeled data.
No synthetic factual negatives for the first V7A run.

## Input/output
Source:
- article content only;
- no title-conditioned retrieval;
- max source length: **768 tokens**.

Target:
- headline;
- max target length: **48 tokens**.

Reason for article-only source: title-conditioned retrieval can self-confirm the candidate headline.

## Loss
Positive teacher-forced seq2seq CE:
- weight **1.0**.

Contrastive same-content ranking:
- compare length-normalized sequence log-likelihood of canonical vs corrupted title.
- pair loss: `softplus(LL_neg - LL_pos)`.
- weight **0.5**.

Total:
`L = L_positive_CE + 0.5 * L_pair_rank`

No arbitrary pair margin is needed in the first version.

## Training configuration
- epochs: **2 fixed**.
- LR: **2e-5**.
- weight decay: **0.01**.
- warmup: **5%**.
- effective batch: ~**32**.
- AMP: FP16 forward.
- master parameters/loss accumulation: FP32.
- gradient checkpointing: enable if needed to fit 768-token source batches on T4×2.
- use T4×2 correctly if data/model parallelism is supported; do not force invalid multi-GPU behavior.

## Per-row scoring
Teacher-force the **observed headline** given the article.

Compute at least:
1. `mean_nll` — length-normalized average target-token NLL.
2. `top2_token_nll` — mean (or defined aggregate) of the two worst target-token NLL values.

Convert each signal to percentile rank within the eligible candidate population.

Precommitted risk:

`risk = 0.5 * percentile(mean_nll) + 0.5 * percentile(top2_token_nll)`

Higher risk = more suspicious.

Do **not** grid-search the 0.5/0.5 weights in V7A.

## Why top-2 worst tokens
Negative headlines often differ by only one factual token/span. Mean likelihood can be diluted by many correct/common tokens; worst-token surprisal is intended to surface the localized corruption.

## Coverage-based intervention
Do not use a raw NLL threshold. Select a **fraction of eligible rows** to flip `1→0`, based on risk ranking.

Fixed DESIGN coverage grid:
- 0%
- 0.2%
- 0.4%
- 0.6%
- 1.0%
- 1.5%
- 2.0%
- 3.0%

Choose the fraction that maximizes full Macro F1 delta vs frozen V5 on DESIGN OOF.

## Prospective split
Create a new connected-component split with:
- seed **260907**.
- 80% DESIGN.
- 20% LOCK.

Within DESIGN:
- 3-fold component-safe CV.

LOCK is untouched until architecture, risk, and coverage are frozen.

## Final training after LOCK passes
Only if V7A passes LOCK:
- train **2 final seeds** on all train labels/data;
- average/aggregate their risk ranks;
- apply the already frozen coverage fraction;
- produce final V7A-on-V5 submission.

Do not reopen coverage after seeing test distribution/public LB.
