# Current Bottleneck Diagnosis

## What is largely solved
### 1. Exact structural/reference signal
V2/V4 exploit exact repeated title/content relationships effectively. Further fuzzy expansion has not produced trustworthy safe coverage.

### 2. Generic semantic relevance
mDeBERTa global NLI is already good enough to identify broad support/topic alignment. More generic semantic blending has not transferred reliably.

## What remains
### Canonical factual construction / binding
Residual mistakes are often a single factual slot:
- which person?
- which institution?
- which province/city?
- which role?
- which number/percentage?
- positive or negated state?
- which entity is attached to which predicate?

The wrong candidate often appears somewhere in the article, so the model must understand **relation binding**, not string presence.

## Why V6-series stopped progressing
V6B showed the verifier can discriminate canonical vs corrupted values when explicitly paired. V6C/D then had to construct those alternatives for arbitrary rows, and candidate generation became the bottleneck.

The listwise V6D ranker was never fairly tested because Stage-0 recall failed before training.

## Strongest unused source of supervision
The dataset has about **11,153 distinct positive article→headline mappings**, and 99.96% of contents with positives have exactly one distinct positive headline.

This is much larger than the ~601 localized corruption pairs.

Therefore the next logical question is not:

> “Can we retrieve the right challenger?”

but:

> “How probable is this observed headline under the article's canonical-headline distribution?”

## Metric diagnosis
For current V5 OOF, `1→0` corrections only need ~41.7% precision to break even on Macro F1. Future selection should optimize full Macro F1, not demand 90% precision.

## Validation diagnosis
The old component folds have been used too often. V7A needs a prospective untouched LOCK split before any new submission.
