# Rejected or Deprioritized Directions

## Another generic NLI backbone / larger XLM-R
Deprioritized because V6A showed changing backbone alone only modestly changed residual discrimination and produced no usable tail.

## XLM-R Large / DeBERTa Large as first next step
No evidence capacity is the main bottleneck. Formulation/data-generation alignment is more important.

## Lowering V6B thresholds after the fact
Rejected. Although 90% was too conservative, V6B actual tail precision was still mostly well below the ~42% Macro-F1 break-even point.

## Existing-score LightGBM/meta stacking
Cross-fitted stacks improved overall discrimination (AUPRC roughly 0.11–0.13 in diagnostics), but high-utility tail behavior did not transport robustly across folds.

## Fuzzy graph / approximate duplicate expansion
Rejected due news-template collisions and weak safe precision outside exact groups.

## Global bipartite matching
Exact positive graph is already close to one-to-one; diagnostics did not reveal meaningful new safe coverage.

## More V4 canonical reranking
A learned reranker did not change the 37 V4 canonical winners in audit.

## Deterministic number/entity rules
Presence and simple mismatch rules have inadequate precision because wrong and right values often both appear in the article.

## Generic headline decomposition / QA
The headline is already short, and generic decomposition can add noise. Dataset-derived factual slots are preferable when needed.

## Continue V6 candidate generation indefinitely
V6C/D showed candidate retrieval itself becomes the bottleneck. V7A bypasses this by scoring the headline directly under article-conditioned generation.
