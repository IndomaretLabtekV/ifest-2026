# Core Research Findings

## 1. Structural information dominates generic semantic OOF
V2 and especially V4 improved public while semantic OOF did not necessarily improve. Exact data structure is a primary signal source.

## 2. OOF improvement alone is insufficient
V3 improved strict semantic OOF to ~0.8493 but public was exactly tied with V2 after 33 changes. Promotion criteria must include evaluator-aligned behavior and falsification, not only a scalar OOF score.

## 3. Residual errors are local factual-binding errors
The remaining negatives often differ by one factual slot while sharing the same topic and most lexical content.

## 4. Localized relative corruption discrimination works
V6B achieved ~94.7% canonical-vs-corrupted ranking on scorable replacement pairs. The model can recognize the factual mutation when given the right comparison.

## 5. Absolute span support does not transfer cleanly to row-level veto
V6B row-risk AUPRC was only ~0.038 on the residual population. “One weakly supported span” creates many false alarms on legitimate positive headlines.

## 6. Candidate generation is a major bottleneck
V6C and V6D showed that finding the correct article-grounded factual challenger is harder than pairwise ranking.

## 7. Open-set distractors are harder than train corruption pairs
Training `canonical > known corruption` is easier than inference `canonical > many article-derived plausible facts`.

## 8. Exact occurrence is not enough
Canonical and corrupted candidates often both appear in the article. The problem is relational binding.

## 9. The old 90% precision veto gate was overly conservative
Metric math gives ~41.7% break-even for `1→0` at V5 OOF. Future selection should optimize full Macro F1, with precision only a guardrail.

## 10. Positive article→headline mapping is almost deterministic
99.96% of unique contents with positives have exactly one distinct positive title. This is a huge, underused supervision source.

## 11. V7A therefore shifts to modeling the data-generating process directly
Instead of constructing challengers, score how likely the observed headline is under an article-conditioned Indonesian seq2seq model.

## 12. Researcher-overfitting is now a real risk
Repeated use of the same seed-2026 folds has influenced many decisions. V7A must use a new untouched LOCK split.
