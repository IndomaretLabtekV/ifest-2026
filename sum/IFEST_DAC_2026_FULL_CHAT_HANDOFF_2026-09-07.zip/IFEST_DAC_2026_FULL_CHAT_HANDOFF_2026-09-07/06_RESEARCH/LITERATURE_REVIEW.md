# Literature Review Used in the Project

This is a research log, not a formal bibliography. The next chat should re-open/cross-check exact bibliographic metadata if needed.

## Evidence retrieval / factual verification
### Zheng et al., Findings ACL 2024 — evidence retrieval bottleneck
Used to support the idea that retrieving superficially similar evidence is not the same as retrieving verdict-relevant evidence. This informed V6B/V6C/V6D shared-evidence and retrieval-first thinking.

### MiniCheck — Tang et al., EMNLP 2024
An efficient factuality checker trained with structured realistic factual errors. Important conceptual support for localized fact units and task-oriented corruptions.

### Optimizing Decomposition for Optimal Claim Verification — ACL 2025
Used to argue that decomposition helps only when atomicity is aligned with the verifier.

### Decomposition Dilemmas — NAACL 2025
Used as caution that generic decomposition can add noise rather than solve factuality.

### AlignScore
Unified semantic alignment across NLI, QA, factual verification, etc. Relevant as background but not chosen as the next implementation direction.

### Dependency-level Entailment — Goyal & Durrett (2020)
Motivated localization of relation-level factual errors rather than only sentence-level entailment.

### Entity-level factual consistency — EACL 2021
Supports explicit modeling of entity-level factual errors.

### SumFC / fine-grained factual consistency
Supports top-K evidence + fine-grained reasoning + contrastive factual examples.

### QAFactEval
QA-based factual consistency reference. Not chosen because the headline task is already short and explicit QA generation adds another failure point.

## Contrastive factuality
### CLIFF — EMNLP 2021
Contrastive learning with factual positives vs minimally corrupted negatives. Strong conceptual match to the real same-content corruption pairs in IFEST.

### Falsesum — NAACL 2022
Task-oriented factual corruption supervision; used as support for realistic in-distribution negative construction rather than arbitrary synthetic negatives.

## Conditional generation / V7A
### BARTScore — arXiv 2106.11520
Frames evaluation as conditional sequence generation and uses sequence likelihood as a quality/factuality signal. This is the most direct conceptual precedent for V7A.

### IndoNLG / IndoBART-v2 — EMNLP 2021
Localized Indonesian generation model family. `indobenchmark/indobart-v2` is ~132M parameters and was chosen because it is Indonesian-focused and feasible on T4×2.

## Multilingual factuality caution
A 2025 multilingual claim verification result on X-Fact reportedly found XLM-R 270M competitive/better than several tested 7–12B LLMs in that setup. This was used as caution against assuming model size alone solves the task.

Separate work on multilingual pretrained LMs also documents cross-lingual factual inconsistency, another reason to prefer an Indonesian-focused generative model for V7A if rules allow it.

## Literature-derived design principles retained
- use realistic in-distribution factual corruptions;
- evaluate evidence retrieval separately from verification;
- prefer atomic factual units when decomposition is needed;
- do not assume larger models dominate;
- conditional generation can serve as a direct compatibility/factuality signal;
- validation protocol matters as much as architecture.
