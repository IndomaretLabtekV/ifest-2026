# Changed-Row and Residual Error Patterns

## V4 public-proven corrections
V4's 16 changes were disproportionately factual slot corrections:
- place/city/province mismatch;
- person identity mismatch;
- role/title mismatch;
- institution mismatch;
- number mismatch;
- negation/polarity mismatch.

Examples recorded in the project:
- Pondok Ranggon vs Srengseng Sawah.
- 2,607 vs 7,573.
- 6,500 vs 5,000 GeNose.
- Slamet Budiarto vs Hadi Pranoto.
- Lamongan vs Malang.
- DPR vs MPR.
- Wagub vs Gubernur Sulsel.
- Danrem vs Kapolda Riau.
- `turun` vs `belum turun`.

## Residual false positives after V5
Examples from the 140 V5-positive pure-fallback negatives:
- “Setahun Usai Lockdown ... Shanghai Hidup Lagi” while article says Wuhan.
- “AHY ... First Wave Tentu Kita Lampaui” while article says `belum bisa lampaui`.
- “Seorang Nakes di Kudus...” while article says Jepara.
- “Kemenhan Jadi Klaster Covid Terbesar di DKI” when article mentions Kemenhan but does not support “largest”.
- “Kapolres Jakpus Bogor ... AKBP Harun Kombes Hengki” mixing roles/locations.
- Khamenei headline while article's top influential Muslim is Erdogan and Khamenei is another rank.
- “Rekor Sembuh Indikator...” while article explicitly says it is not an indicator.
- “Liga 1 dan IBL ... Izin Menpora” while article says police permit.
- “PERSI Minta Dokter...” while body says PB IDI.
- “Gubri ... Sekolah Tatap Muka” while body says Gubsu.
- “Kematian Covid Sultra Meningkat 363 Persen” where 363 is a count elsewhere and deaths rose ~300%.

## Interpretation
These are usually **binding** failures. The wrong entity/number may appear in the article, so presence alone does not prove support. The system must model which candidate belongs to which predicate/relation/context.
