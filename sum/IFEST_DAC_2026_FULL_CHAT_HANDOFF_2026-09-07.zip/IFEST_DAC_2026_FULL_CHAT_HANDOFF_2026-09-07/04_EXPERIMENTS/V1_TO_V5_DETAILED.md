# Detailed Experiment History — V1 to V5

## V1 — AMP-fixed multilingual NLI baseline
Backbone:
- `MoritzLaurer/mDeBERTa-v3-base-xnli-multilingual-nli-2mil7`
- NLI mapping: entailment=0, neutral=1, contradiction=2.

Training:
- 3 folds × 2 epochs.
- max_len 384.
- LR `1.5e-5`.
- negative class weight 3.
- pairwise lambda 0.25.
- margin 0.5.

Results:
- strict semantic OOF ~0.8365.
- meta OOF ~0.8406.
- graph-like diagnostics ~0.922.
- final test negatives ~368.
- Public: **0.93367**.

Interpretation: useful semantic baseline, but leaves strong structural signal untapped.

---

## V2 — Global + Local Multi-Instance NLI
Added:
- global + local evidence views;
- partial NLI;
- same-content counterfactual pairwise training;
- conservative synthetic counterfactuals;
- calibrated meta layer;
- safer graph logic.

Representative config:
- global max 384.
- local 224.
- 3 local views.
- global loss 0.35, local 0.65.
- batch 6, eval 12, grad accumulation 5.
- LR `1.5e-5`.
- negative weight 3.

Results:
- strict semantic OOF ~0.8288 (worse than V1).
- meta ~0.8365.
- global branch alone ~0.8355.
- local pooled ~0.8189.
- 75% global +25% local recombination ~0.8391.
- graph-like ~0.9244–0.9249.
- test final negatives ~369.
- Public: **0.94856**.

Key conclusion: structural logic improved LB despite weaker semantic OOF.

---

## V3 — Surgical Semantic Recomposition
No retraining.

Semantic blend:
- 45% V1 meta.
- 55% V2 meta.
- V2 graph frozen.

Results:
- strict OOF ~**0.84930**.
- harder cross-fitted ~0.844–0.845.
- 33 test changes vs V2.
- all were semantic fallback changes and effectively reverted V2 labels toward V1.
- Public: **0.94856**, exact tie.

Conclusion: better generic semantic OOF did not translate. Do not use OOF improvement alone as promotion evidence.

---

## V4 — Transductive Canonical Matching
No neural retraining.

Core rule:
- operate only on unresolved test rows;
- exact normalized same-content groups;
- require multiple distinct titles;
- content length gate;
- exclude groups where positive title is already known from train;
- select exactly one canonical positive using a frozen rank built from V3/V2 semantic scores.

Structural facts supporting the rule:
- 893 same-content multi-title train groups.
- 873 (~97.76%) exactly one positive.

Actual test behavior:
- canonical rule touched 78 rows / 37 groups.
- only **16 final labels changed vs V2**.
- **15 × 1→0**, **1 × 0→1**.

Validation:
- pseudo competition originally 100/100 wins; mean gain ~+0.0079.
- component-transductive validation ~0.8908.

Public:
- **0.95681**.

Representative corrections:
- Pondok Ranggon → Srengseng Sawah.
- 2,607 → 7,573.
- 6,500 → 5,000 GeNose.
- Slamet Budiarto → Hadi Pranoto.
- Lamongan → Malang.
- DPR → MPR.
- Wagub → Gubernur Sulsel.
- Danrem → Kapolda Riau.
- `turun` → `belum turun`.
- Pantai Siring Kemuning → Tlangoh.
- one positive rescue involving Kapolda Kalteng `Terima Kasih`.

V4 is the strongest public-proven evidence in the project.

---

## V5 — Asymmetric Global Consensus Rescue
Frozen V4 plus only `0→1` rescues on pure V2 fallback rows.

Gate:
- V4 label 0;
- pure V2 fallback;
- V3 blend ≥0.67;
- V2 global entailment ≥0.50.

Actual test changes:
- **4 rows**, all `0→1`.

Validation:
- component rescue audit: 25/25 OOF rescue candidates true positive.
- mean component metric ~0.89079 → ~0.89451 (+0.00372).
- pseudo: 99 wins / 1 tie / 0 losses; mean +0.00349.

Public:
- **0.95681**, exact V4 tie.

Interpretation:
- public tie does not strongly falsify V5 because only four rows changed;
- private sign is unknown;
- V5 remains a defensible frozen base because validation was strong and intervention tiny.
