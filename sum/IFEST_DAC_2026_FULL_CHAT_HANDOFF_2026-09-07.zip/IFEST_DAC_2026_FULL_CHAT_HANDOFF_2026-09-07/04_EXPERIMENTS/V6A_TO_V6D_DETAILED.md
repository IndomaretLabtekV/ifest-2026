# Detailed Experiment History — V6A to V6D

## V6A — XLM-R Residual Contradiction Specialist
Goal: attack V5-positive pure-fallback residual false positives with a different NLI backbone.

Backbone:
- `symanto/xlm-roberta-base-snli-mnli-anli-xnli`.

Candidate population:
- ~11,687 V5-positive pure fallback rows.
- only **140 genuine negatives = 1.198%**.

Training:
- 3 folds, 1 epoch/fold.
- LR `1e-5`.
- batch 12, grad accumulation 3.
- 25% positive sampling around hard negatives; this later looked too aggressive because much legitimate positive diversity was discarded.

Results:
- raw ROC-AUC ~**0.656**.
- AUPRC ~**0.0207** (random baseline ~0.012).
- fold AUPRC ~0.0273 / 0.0259 / 0.0167.
- no threshold met the 90%-precision gate.
- 0 OOF veto, 0 test veto.
- submission identical to V5.

Conclusion: backbone diversity alone is not enough.

---

## V6B — Counterfactual Span-Level Factual Support Verifier
Motivation: whole-headline NLI misses one-token factual corruptions.

Backbone:
- return to mDeBERTa multilingual NLI base.

Strong supervision:
- ~601 clean real counterfactual pairs mined from exact same-content groups.
- localized factual spans.

Architecture:
- candidate spans for numbers, polarity, high-information lexical spans.
- masked-target evidence retrieval.
- score span support from shared article windows.
- row risk = weakest span / strongest unsupported signal.
- only high-confidence `1→0` veto on frozen V5 pure fallbacks.

Training objective:
- strong span BCE.
- pairwise rank loss.
- weak row-level MIL on unresolved rows.

Runtime fix:
- initial notebook crashed because `F.binary_cross_entropy` was executed inside autocast.
- corrected by limiting autocast to model forward and computing softmax/BCE/MIL/pair losses in FP32.

Results:
- replacement-pair ranking ~**94.7%** on 472 scorable pairs.
- unsupported-span AUPRC ~**0.934–0.940**.
- residual row-risk ROC-AUC ~**0.696**.
- residual row-risk AUPRC ~**0.0376**.
- top-risk precision only around 5–20%.
- cross-fitted threshold failed; 0 veto.
- pseudo: 0 wins / 100 ties.
- final submission exactly V5.

Key scientific result: **relative localized corruption discrimination works; absolute row-level calibration/aggregation does not.**

---

## V6C — Article-Grounded Counterfactual Slot Challenger Ranker
Motivation: convert V6B's successful relative skill into deployment by asking “original value or article-grounded challenger?”

Planned:
- explicit slots for lexical/entity, number, polarity.
- shared evidence per slot.
- article-derived challengers.
- same-slot/same-challenger fold consensus.

Actual critical bug:
- lexical candidate eligibility used the 80th percentile of unique vocabulary IDF values.
- in this corpus, 80th percentile equaled the maximum/hapax IDF (~9.8817).
- result: **0 / 431 canonical lexical spans were eligible**.

Actual generator results:
- overall recall **7.99%**.
- lexical: **0/431**.
- number: **8/41 = 19.5%**.
- polarity: **40/129 = 31.0%**.
- top-1 conditional on canonical generated: ~41.7%.
- coverage-adjusted success: ~3.33%.
- 0 veto.

Second implementation bug:
- the final artifact export block was accidentally a Markdown cell, so the executed notebook did not actually run the intended export code.

Conclusion: current V6C run is invalid as evidence against the challenger hypothesis.

---

## V6D — Retrieval-First Listwise Factual Slot Ranker
Motivation: fix V6C generator pathology and train on inference-like article-derived distractor sets.

Key design:
- Stage-0 candidate generator must pass before GPU training.
- lexical raw pool up to ~96 candidates, cheap pre-ranker to final 12–24.
- atomic number parsing.
- polarity as state, not ordinary lexical token.
- listwise ranker on canonical among article-derived distractors.
- positive controls.
- no row-level negative MIL.

Actual Stage-0 results:
- lexical raw recall: **80.28%**.
- lexical recall after pruning: **60.32%**.
- number recall: **31.71%**.
- polarity availability: **31.01%**.
- promoted types: **0**.
- Stage-0: FAIL.

Correct behavior:
- Transformer training skipped.
- 0 OOF/test veto.
- component gain 0.
- pseudo 0 wins /100 ties.
- submission bit-for-bit identical to V5.

Conclusion: V6D is a valid negative generator run; the listwise neural ranker itself remains untested because the retrieval precondition failed.
