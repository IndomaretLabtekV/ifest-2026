# Experiment Matrix — V1 through V6D

| Version | Core idea | Main validation result | Test behavior | Public/decision |
|---|---|---|---|---|
| V1 | mDeBERTa NLI baseline + graph/meta | strict/meta OOF ~0.84 | ~368 negatives | 0.93367 |
| V2 | global/local MIL NLI + safer graph | semantic OOF not better; graph-like ~0.924 | ~369 negatives | **0.94856** |
| V3 | 45% V1 +55% V2 semantic recomposition | strict OOF ~0.8493 | 33 changes vs V2 | **0.94856 tie** |
| V4 | exact test-test canonical matching | pseudo very strong; transductive component gain | 16 changes vs V2 | **0.95681** |
| V5 | asymmetric high-confidence positive rescue | strong OOF/pseudo rescue evidence | 4 changes vs V4 | **0.95681 tie** |
| V6A | XLM-R residual contradiction specialist | AUPRC ~0.021, AUC ~0.656 | 0 veto | DO NOT SUBMIT |
| V6B | counterfactual span support verifier | pair rank ~94.7% on scorable replacements; residual AUPRC ~0.038 | 0 veto | DO NOT SUBMIT |
| V6C | article-grounded slot challenger | generator recall ~8%; critical IDF bug | 0 veto | invalid as hypothesis test |
| V6D | retrieval-first listwise slot ranker | Stage-0 generator fails; training skipped | identical V5 | DO NOT SUBMIT |

## Main interpretation
- V2/V4 show **structure transfers to LB**.
- V3 shows **generic semantic OOF can be misleading**.
- V6B shows **localized relative factual discrimination is learnable**.
- V6C/D show **candidate generation is an expensive bottleneck and open-set factual binding is harder than pairwise corruption ranking**.
- This motivates V7A's move away from explicit challenger generation.
