# Expected V7A Outputs

The next V7A notebook should export enough diagnostics for a rigorous submission audit.

Recommended outputs:
- `config_v7a.json`
- `provenance_v7a.json`
- `design_split_manifest_v7a.csv`
- `design_fold_metrics_v7a.csv`
- `design_oof_scores_v7a.csv`
- `pair_ranking_metrics_v7a.csv`
- `coverage_search_v7a.csv`
- `lock_metrics_v7a.csv`
- `lock_selected_rows_v7a.csv`
- `lock_bootstrap_v7a.csv`
- `training_history_v7a.csv`
- `test_scores_v7a.csv`
- `changed_rows_v7a.csv`
- `submission_v7a.csv` only if accepted; if fail-closed, still export an explicit fallback file but mark acceptance false.
- `v7a_summary.json`
- optional `results_v7a.zip` bundling diagnostics.

Every summary should record:
- acceptance flag;
- chosen DESIGN coverage;
- design/lock deltas;
- number/direction of test changes;
- frozen-row integrity checks;
- package/checkpoint versions;
- seeds.
