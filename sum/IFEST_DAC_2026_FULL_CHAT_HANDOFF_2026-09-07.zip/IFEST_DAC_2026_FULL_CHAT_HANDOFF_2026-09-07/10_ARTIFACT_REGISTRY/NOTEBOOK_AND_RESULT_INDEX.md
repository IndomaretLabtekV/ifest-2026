# Notebook and Result Artifact Registry

This file lists artifacts referenced in the chat. **They are not included in this documentation ZIP.** Paths are historical/current-container references and may not exist in a new chat/runtime.

## Notebooks
- `IFEST_DAC_2026_V1_1_1_AMP_Fixed_NLI_Baseline.ipynb`
- `IFEST_DAC_2026_V2_Global_Local_MIL_NLI.ipynb`
- `IFEST_DAC_2026_V3_Surgical_Recomposition.ipynb`
- `IFEST_DAC_2026_V4_Transductive_Canonical_Matching.ipynb`
- `IFEST_DAC_2026_V5_Asymmetric_Global_Consensus_Rescue.ipynb`
- user-run V6A: `v6A.ipynb`
- `IFEST_DAC_2026_V6B_Counterfactual_Span_Factual_Verifier.ipynb`
- revised AMP-safe V6B: `IFEST_DAC_2026_V6B_Counterfactual_Span_Factual_Verifier_AMP_Fixed.ipynb`
- `IFEST_DAC_2026_V6C_Article_Grounded_Counterfactual_Slot_Challenger_Ranker.ipynb`
- `IFEST_DAC_2026_V6D_Retrieval_First_Listwise_Factual_Slot_Ranker.ipynb`
- **V7A notebook: not yet created in the current chat at handoff time.**

## V1 result files mentioned
- `oof_v1_1_1.csv`
- `test_scores_v1_1_1.csv`
- `submission_v1_1_1.csv`
- training history / summary artifacts.

## V2 result files mentioned
- `oof_v2.csv`
- `test_scores_v2.csv`
- `submission_v2.csv`
- graph diagnostics.
- slice diagnostics.
- training history.

## V3
- `oof_v3.csv`
- `test_scores_v3.csv`
- `submission_v3.csv`
- `changed_rows_v3.csv`
- metrics.

## V4
- `canonical_groups_v4.csv`
- `changed_rows_v4.csv`
- `component_transductive_metrics_v4.csv`
- `pseudo_competition_metrics_v4.csv`
- `structural_profile_v4.csv`
- `submission_v4.csv`
- `test_scores_v4.csv`

## V5
- `canonical_groups_v5.csv`
- `changed_rows_v5.csv`
- `component_rescue_metrics_v5.csv`
- `pseudo_competition_v5.csv`
- `rescue_validation_v5.csv`
- `structural_profile_v5.csv`
- `submission_v5.csv`
- `test_scores_v5.csv`

## V6A
- `changed_rows_v6.csv`
- `config_v6.json`
- `crossfit_veto_metrics_v6.csv`
- `oof_xlmr_specialist_v6.csv`
- `pseudo_competition_v6.csv`
- `specialist_fold_metrics_v6.csv`
- `submission_v6.csv`
- `test_scores_v6.csv`

## V6B
Referenced result family included:
- counterfactual pair diagnostics;
- span pair metrics;
- residual candidate scores;
- cross-fit veto metrics;
- pseudo competition;
- final submission V6B.

Key fact: final V6B submission was exactly identical to V5.

## V6C
Run notebook: `v6C.ipynb`.
Result logic had generator diagnostics but final export code in the uploaded notebook was accidentally Markdown.

## V6D
User uploaded:
- `v6D.ipynb`
- `results-v6D.zip`

Key result:
- Stage-0 failed;
- training history/model ranking outputs empty because neural training was skipped;
- `submission_v6d.csv` bit-for-bit identical to `submission_v5.csv`.

Known identical SHA-256 from audit for V5/V6B/V6D-style final CSV:
`698790750562fda1dcc7eea78ac428d079312254b535f9aedf85fb240422dfdc`

## Historical local directories mentioned
- `/mnt/data/results_v1_unzipped/`
- `/mnt/data/results_v2_unzipped/`
- `/mnt/data/results_v3_unz/`
- `/mnt/data/results_v4_unz/`
- `/mnt/data/results_v5_unz/`
- `/mnt/data/results_v6A_unz/`

Treat all paths as historical references, not guaranteed portable locations.
