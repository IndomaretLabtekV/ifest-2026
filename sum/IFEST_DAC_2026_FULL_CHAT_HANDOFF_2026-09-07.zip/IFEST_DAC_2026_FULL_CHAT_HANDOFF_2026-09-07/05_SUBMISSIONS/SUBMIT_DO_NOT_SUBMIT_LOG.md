# Submission Decision Log

## V1 — SUBMITTED
Reason: baseline reference.

## V2 — SUBMITTED
Reason: strong structural hypothesis, large public improvement.

## V3 — SUBMITTED
Outcome: exact public tie with V2; became a falsification signal against semantic blend promotion.

## V4 — SUBMITTED
Reason: strong train pseudo-competition, exact structural logic, low coverage. Outcome validated: **0.95681**.

## V5 — SUBMITTED
Reason: only four high-confidence positive rescues with strong OOF/pseudo evidence. Public tied V4; private unknown.

## V6A — DO NOT SUBMIT
- zero active vetoes;
- submission == V5.

## V6B — DO NOT SUBMIT
- localization succeeded but residual veto failed;
- zero test changes;
- submission == V5.

## V6C — DO NOT SUBMIT
- critical candidate-generator bug;
- 0 active changes;
- export block bug;
- not a valid test of underlying challenger hypothesis.

## V6D — DO NOT SUBMIT
- Stage-0 generator failed;
- Transformer ranker intentionally skipped;
- zero changes;
- bit-for-bit identical to V5.

## V7A — NOT YET RUN
Submission decision must depend on prospective DESIGN+LOCK acceptance. Do not submit if LOCK fails.
