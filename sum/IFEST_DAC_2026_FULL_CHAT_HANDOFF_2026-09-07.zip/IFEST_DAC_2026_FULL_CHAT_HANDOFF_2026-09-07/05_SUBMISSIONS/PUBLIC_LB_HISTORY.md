# Public Leaderboard History

## Known submissions
### V1
- Public: **0.93367**.

### V2
- Public: **0.94856**.
- Improvement vs V1: +0.01489.

### V3
- Public: **0.94856**.
- Exact tie with V2 despite 33 changed rows and better semantic OOF.

### V4
- Public: **0.95681**.
- Improvement vs V2/V3: +0.00825.
- Only 16 final changed rows vs V2.

### V5
- Public: **0.95681**.
- Four additional `0→1` changes vs V4.
- Public tie; private effect unknown.

### V6A/B/C/D
- Do not submit / no information gain.
- V6A/B/D final predictions were effectively identical to V5; V6C also had zero active changes and implementation issues.

## Current competitor context
Current observed Top-1: **0.98979**.

This should motivate a new source of information, not random submission volume.
