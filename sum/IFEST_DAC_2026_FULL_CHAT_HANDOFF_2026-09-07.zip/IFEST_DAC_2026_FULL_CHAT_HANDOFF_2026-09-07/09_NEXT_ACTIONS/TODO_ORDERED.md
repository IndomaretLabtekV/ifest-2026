# Ordered Next Actions

## 0. Verify official rule first
Before any V7A notebook run:
- re-check latest IFEST guidebook/FAQ/organizer notice on pretrained open-weight models;
- confirm `indobenchmark/indobart-v2` use is allowed;
- confirm no rule change since the prior guidebook audit.

If not allowed, stop and redesign within rules rather than running V7A illegally.

## 1. Implement V7A notebook
The previously requested V7A implementation was **not completed** before this handoff request interrupted it.

Implement exactly `08_CURRENT_STATE/V7A_DESIGN.md` and `V7A_ACCEPTANCE_CONTRACT.md`.

Requirements:
- Kaggle T4×2 end-to-end.
- no local training.
- reproducible.
- robust dependency/checkpoint handling.
- compact notebook if user keeps the <1MB requirement.
- frozen V5 reconstruction/alignment guards.

## 2. Run V7A on Kaggle
Run complete DESIGN CV and only then LOCK evaluation.

Do not inspect/tune LOCK early.

## 3. Audit V7A results
Required review:
- sequence likelihood distributions by label;
- pair-ranking accuracy;
- DESIGN per-fold Macro F1 delta;
- selected coverage;
- LOCK delta/precision/bootstrap;
- changed-row examples;
- whether high-risk rows correspond to entity/number/polarity factual slots;
- any length/style bias where rare-but-valid headlines receive bad likelihood.

## 4. Decide first submission
If all V7A acceptance gates pass:
- train final two seeds on all train;
- freeze coverage from DESIGN;
- generate V7A-on-V5 submission;
- this becomes the recommended first new submission.

If V7A fails LOCK:
- do **not** submit V7A;
- keep V4/V5.

## 5. Only after V7A audit, design the next research branch
Do not preemptively create V7B/V8 before seeing whether article→headline conditional likelihood transfers.
