# Decision Tree

## Step 1 — Is IndoBART-v2 allowed by the latest official rules?
- **No:** do not run V7A; redesign within rules.
- **Yes:** continue.

## Step 2 — Does V7A DESIGN CV pass?
Need:
- gain ≥+0.0015;
- ≥2/3 positive folds;
- worst fold >−0.0005;
- pair ranking ≥90%;
- nonzero selected coverage.

If **no** → reject V7A, no submission.
If **yes** → freeze everything and open LOCK.

## Step 3 — Does LOCK pass?
Need:
- Macro F1 delta >0;
- selected-veto precision ≥50%;
- bootstrap positive delta ≥80%;
- no frozen structural violations.

If **no** → V7A dead; do not retune LOCK.
If **yes** → final two-seed full-train fit.

## Step 4 — Final test sanity
- expected 5–90 changes;
- no locked V2/V4/V5 rows changed;
- no ID mismatch;
- no distribution anomaly.

If sane → **first new submission candidate**.
If not sane → fail closed and audit before submitting.
