# Kaggle Run Checklist for V7A

## Before launch
- [ ] Latest competition rule on pretrained checkpoint confirmed.
- [ ] Accelerator is T4×2.
- [ ] Dataset paths discovered robustly rather than hardcoded to a single folder name if possible.
- [ ] Frozen V5 artifacts/reconstruction verified by ID order and expected label counts.
- [ ] Component builder reproduces expected train size/components.
- [ ] New `SEED_LOCK=260907` split created once and logged.
- [ ] LOCK labels are not used in DESIGN decisions.

## Dependency/checkpoint
- [ ] `transformers`, tokenizer/model dependencies compatible with Kaggle Python/PyTorch.
- [ ] model checkpoint downloads/retrieval failures produce clear error messages.
- [ ] exact package versions exported to provenance JSON.

## Training
- [ ] all seeds set.
- [ ] positive mapping deduplicated as specified.
- [ ] contrastive pair groups stay component-safe.
- [ ] source max_len 768, target max_len 48.
- [ ] epochs 2, LR 2e-5, WD 0.01, warmup 5%.
- [ ] AMP scope is safe.
- [ ] gradient checkpointing used only if necessary.
- [ ] model states offloaded between folds if GPU residency could exceed T4 memory.

## Scoring
- [ ] teacher-forced token NLL excludes pad tokens.
- [ ] mean NLL is length-normalized correctly.
- [ ] top-2 worst token NLL deterministic and documented.
- [ ] risk weights fixed 0.5/0.5.
- [ ] percentile/rank computation uses only eligible population and is deterministic.

## DESIGN selection
- [ ] only fixed coverage grid searched.
- [ ] full Macro F1 delta vs V5 computed for each coverage.
- [ ] chosen coverage and DESIGN metrics frozen before LOCK.

## LOCK
- [ ] LOCK evaluated once.
- [ ] no retuning after seeing LOCK.
- [ ] LOCK precision, Macro F1 delta, bootstrap stability saved.

## Final export if accepted
- [ ] train two final seeds on all train.
- [ ] use frozen coverage.
- [ ] V2/V4/V5 locked rows unchanged.
- [ ] submission columns exactly `id,label`.
- [ ] row count 3,603.
- [ ] ID order matches sample submission.
- [ ] diagnostics/results zip generated.
- [ ] changed rows file generated for audit.
