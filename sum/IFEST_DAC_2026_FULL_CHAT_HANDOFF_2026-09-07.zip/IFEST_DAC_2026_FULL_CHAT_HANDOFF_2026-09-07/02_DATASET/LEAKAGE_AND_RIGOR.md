# Data Rigor, Leakage, and Artifact Policy

## What is legitimate signal
The project explicitly treats exact title/content repetitions and same-content candidate groups as **dataset structure**, not hidden-label leakage, as long as the validation split keeps related components together and test labels are never used.

## Main leakage risk
If exact same-title/content relatives cross train/validation folds, OOF metrics become artificially inflated. Therefore strict experiments use connected-component grouping over normalized exact title/content.

## Component-safe CV
The default strict split used through V1–V6 was:
- 3-fold `StratifiedGroupKFold`.
- group = connected component over exact normalized title/content.
- seed = **2026**.

This keeps exact relatives in one fold.

## Threshold leakage control
Later veto experiments used cross-fitted thresholds:
- threshold for held-out fold `k` is learned from other folds only.
- no selecting a threshold on the same fold where its performance is reported.

## Transductive V4
V4 used test-test exact-content groups. This is transductive but label-free. Its rules were first falsified on train-like pseudo settings and then applied to test.

## Researcher-overfitting risk
Even technically leakage-safe old OOF folds have now influenced many architectural decisions across V1–V6. Therefore V7A introduces a **new prospective 20% LOCK split** whose labels are not used for architecture, coverage, or threshold selection.

This is a different problem from ordinary data leakage: it is repeated human/research tuning against the same OOF surface.

## Public leaderboard leakage policy
Public LB is used as a sparse external check. Do not tune row-level rules against public score changes. Public is only 30%; private is 70%.

## External data policy
No external labeled data or external ground truth has been used in the research branch. Pretrained model weights are subject to official competition rule confirmation.
