# Counterfactual Mining and Localized Corruption Supervision

A key discovery after V6A was that exact same-content groups provide **real in-distribution corruptions**.

## Pre-design audit
From groups with exactly one canonical positive headline and one or more negative headlines:
- about **913** canonical-positive ↔ negative-title pairs.
- mean edit operations ~**1.37**.
- ~**71.96%** have exactly one edit operation.
- ~**72.07%** have a negative changed span of ≤3 tokens.
- median changed span on both positive and negative sides is 1 token.
- high-similarity subset (`title diff ratio ≥0.8`): **619 pairs**, ~97.25% single edit operation.

Conservative high-quality filter produced **602** pairs in the design audit:
- approximate taxonomy: 442 entity/lexical/other, 119 polarity, 41 number.

The executable V6B pipeline later yielded **601** clean pairs after its exact dedup/filter implementation. Keep the distinction: **602 was the design-stage count; 601 was the run-time mined count**.

## V6B operation taxonomy on 601 pairs
- replacement: **472**
- deletion: **111**
- insertion: **18**

The deletion/insertion cases are overwhelmingly negation/polarity states:
- `tak`, `belum`, `jangan`, `tidak`, `bukan`, or `<NONE>`.

## Strong replacement evidence
For 472 scorable replacement pairs:
- V6B canonical-vs-corrupted ranking accuracy: ~**94.7%**.
- unsupported-span AUPRC: ~**0.934–0.940**.

This was major evidence that local factual corruption is learnable if the model is given the right comparison.

## Important coverage caveat
The 94.7% pair-ranking headline excluded deletion/insertion pairs because the V6B span representation could not score them equivalently. Therefore it was **94.7% conditional on scorable replacement pairs**, not on all 601 counterfactual pairs.

## Article occurrence audit
For replacement pairs:
- canonical changed span appears exactly in the article ~**96.2%** of the time.
- corrupted span also appears in the article ~**37.1%** of the time.
- both appear ~**35.6%** of the time.

For V6C lexical canonical spans specifically:
- **413 / 431 = 95.8%** appear in the article.

So simple string occurrence is insufficient. The difficult problem is **binding the correct candidate to the correct relation/predicate**.
