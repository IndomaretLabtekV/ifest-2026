# Dataset Profile

## Core schema
### Train
- Rows: **14,397**
- Columns: `id`, `title`, `content`, `label`

### Test
- Rows: **3,603**
- Columns: `id`, `title`, `content`

## Label distribution
- `label=0`: **1,437 (9.98%)**
- `label=1`: **12,960 (90.02%)**

This is a large imbalance by frequency, but the evaluation metric is Macro F1, so optimizing ordinary accuracy or probability calibration alone is inappropriate.

## Text profile
- Mean headline length: ~**9.95 words**.
- Train headline range observed in later planning: roughly **3–22 words**.
- Mean article length: ~**310 words**.
- Some article content exceeds **4,000 words**.
- Later source-length audit: article P90 ~**466 words**, P95 ~**581 words**.
- Domain is dominated by Indonesian news, with heavy COVID-era coverage and repeated entities/events/templates.

## Typical negative construction
Negatives are commonly subtle edits:
- person/entity substitution;
- organization substitution;
- province/city/location substitution;
- role swap;
- number/percentage/count substitution;
- polarity/negation insertion/deletion;
- action or predicate swap;
- factual binding where all entities/numbers appear in the article but are attached to the wrong predicate.

Representative residual errors seen during audits:
- Shanghai vs Wuhan.
- Gubri vs Gubsu.
- KPAI vs LPAI.
- Kemenhub vs Kemenhan.
- PERSI vs PB IDI.
- police permit vs Menpora permit.
- 363 used as the wrong factual quantity while a different percentage is the correct claim.
- `belum bisa lampaui` changed to an affirmative claim.

## Practical consequence
The task is not ordinary topic relevance. A model can understand the article topic and still miss the single corrupted factual slot.
