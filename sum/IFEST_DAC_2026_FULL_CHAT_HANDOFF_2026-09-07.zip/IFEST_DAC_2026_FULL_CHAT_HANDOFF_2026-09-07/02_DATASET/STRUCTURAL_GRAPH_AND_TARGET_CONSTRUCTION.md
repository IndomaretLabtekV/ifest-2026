# Structural Graph and Target-Construction Evidence

## Exact overlap
After normalization:
- **927 / 3,603 test pairs = 25.73%** have an exact `title+content` pair occurring in train.
- No conflicting labels were found among these exact train pairs.

This is enormous transductive/reference coverage.

## Connected components
Build a graph connecting rows that share exact normalized `title` or exact normalized `content`.

Observed:
- **11,525 connected components**.
- **5,419 train rows** belong to non-singleton components.

This graph became the basis for strict component-safe CV and for freezing structural decisions.

## Same-content multiple-title groups
Train contains **893** contents with multiple distinct headline candidates.
- **873 / 893 = 97.76%** have exactly one positive title.

This property directly motivated V4 canonical matching.

## Near-deterministic article→headline mapping
Among **11,142 unique contents with at least one positive title**:
- **11,138 = 99.96%** have exactly one distinct positive headline.

Distinct deduplicated positive article/headline mappings: about **11,153**.

This is the strongest empirical reason for V7A: the data behaves almost like a conditional generation problem where the article has one canonical headline and negatives are corrupted alternatives.

## Why fuzzy graph extensions were rejected
COVID/news articles have extremely high lexical overlap across dates and related updates. Near-duplicate content matching can connect legitimately different articles where only date/entity/number changed. Therefore exact structural rules are high precision, but fuzzy structural expansion was not trusted.

## V4 structural profile
Same-content multi-title groups are mostly one-positive, and longer-content groups have even cleaner canonical behavior. V4 used exact normalized content, candidate diversity, known-positive exclusions, and frozen semantic rank only as a tie/rank signal.
