# Decision Timeline

## Baseline phase
1. Build mDeBERTa NLI baseline (V1).
2. Discover that exact structural relations are large and valuable.
3. Build V2 global/local + safer graph; public jumps to 0.94856 despite weaker semantic OOF.

## Semantic recomposition phase
4. V3 blends V1/V2 semantics; strict OOF improves.
5. Public stays exactly tied with V2 after 33 changes.
6. Decision: generic semantic OOF is not enough evidence.

## Structural canonical phase
7. Audit same-content groups: overwhelming one-canonical-positive pattern.
8. V4 test-test exact-content canonical inference.
9. 16 changes yield public 0.95681.
10. Decision: exact structural logic is highest-confidence lever.

## Conservative rescue phase
11. V5 adds four high-confidence `0→1` rescues.
12. OOF/pseudo strong; public tie.
13. Decision: freeze V5 rescues for future private-oriented experiments; V4 remains public-proven anchor.

## Residual specialist phase
14. V6A XLM-R specialist: weak AUPRC, no usable veto.
15. Deep audit finds 601/602 real localized counterfactual supervision source.
16. V6B span-level verifier: pair ranking works, row-level veto does not.
17. Diagnosis: training skill is relative but deployment was absolute.

## Challenger phase
18. V6C tries article-grounded challenger ranking.
19. Audit finds critical IDF eligibility bug and export cell bug.
20. Underlying challenger hypothesis remains unresolved.
21. V6D redesigns generator as retrieval-first and makes Stage-0 recall a gate.
22. Stage-0 fails: lexical raw 80.28%, pruned 60.32%, number 31.71%, polarity 31.01%.
23. Ranker training skipped; zero changes; do not submit.

## Metric + generative pivot
24. Top-1 observed at 0.98979.
25. Re-audit Macro F1 utility: `1→0` break-even precision ~41.7%, not 90%.
26. Re-audit target construction: article→positive-headline mapping is ~99.96% one-to-one.
27. Decision: stop V6 challenger branch and pivot to direct conditional generation.
28. Design V7A IndoBART conditional headline likelihood verifier with prospective 80/20 DESIGN/LOCK split.
29. User requested V7A implementation, but the handoff request arrived before implementation was completed.

## Current state
Next action is to verify the latest pretrained-model rule and implement/run V7A exactly as documented.
