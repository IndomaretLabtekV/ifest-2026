# Frozen Decisions and Contracts

Unless a future experiment is explicitly designed to challenge these, preserve them.

## V2/V4/V5 hierarchy
- V2 train-reference structural graph decisions are locked.
- V4 exact test-test canonical decisions are locked.
- V5 four rescue rows are locked for residual experimentation.

## Direction for semantic residual correction
V6/V7-style residual experiments operate only on V5-positive pure fallback rows and only propose `1→0`, unless a new approved design says otherwise.

## No post-hoc threshold relaxation
Do not reinterpret failed V6 results by lowering thresholds after seeing outcomes. New metric-aligned thresholds belong in a newly precommitted experiment, which V7A does.

## No public-LB row tuning
Do not reverse-engineer individual public rows from score changes.

## V7A prospective lock
Once `SEED_LOCK=260907` DESIGN/LOCK split is created and V7A DESIGN choices are made:
- do not use LOCK to redesign;
- evaluate LOCK once;
- reject if it fails.

## No local training
All actual training/experimentation remains on Kaggle per user instruction.
