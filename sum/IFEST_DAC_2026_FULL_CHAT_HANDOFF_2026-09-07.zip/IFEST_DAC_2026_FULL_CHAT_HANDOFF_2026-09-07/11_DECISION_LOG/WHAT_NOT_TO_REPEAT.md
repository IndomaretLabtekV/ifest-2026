# What Not to Repeat

1. **Do not promote a version because OOF scalar improved.** V3 disproved that shortcut.
2. **Do not use 90% veto precision as a universal gate.** It was not Macro-F1 aligned.
3. **Do not simply lower old V6 thresholds.** Their actual tail was still below break-even.
4. **Do not keep swapping generic backbones without a new information source.** V6A was weak.
5. **Do not use hard IDF eligibility thresholds over vocabulary-type quantiles.** V6C collapsed lexical recall to zero.
6. **Do not report conditional ranking without coverage-adjusted success.** V6B/V6C diagnostics can otherwise look deceptively strong.
7. **Do not let title-conditioned retrieval self-confirm a candidate when evaluating conditional likelihood.** V7A uses article-only source.
8. **Do not expand fuzzy graph aggressively.** News templates collide.
9. **Do not retain all fold models on T4×2 simultaneously.** Offload/snapshot between folds.
10. **Do not leave export code as Markdown or assume notebook cell types are correct.** Verify executable export cells.
11. **Do not keep using the same old folds as if they were a fresh test set.** V7A introduces a prospective LOCK.
12. **Do not submit zero-change variants.** They provide no leaderboard information.
