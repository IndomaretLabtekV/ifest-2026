# Executive Handoff Summary

## Task
Binary classification on Indonesian news:
- `label = 1`: headline is factually supported by the article content.
- `label = 0`: headline contains a factual mismatch/corruption relative to the article.
- Evaluation: **Macro F1**.
- Submission columns: `id,label`.

The class distribution is highly imbalanced (~90% positive / ~10% negative), but Macro F1 means minority-class corrections are disproportionately valuable.

## Dataset scale
- Train: **14,397 × 4** (`id,title,content,label`).
- Test: **3,603 × 3** (`id,title,content`).
- Train negatives: **1,437 = 9.98%**.
- Train positives: **12,960 = 90.02%**.
- Mean title length: ~**9.95 words**.
- Mean content length: ~**310 words**; some articles >4,000 words.
- Later token-length audit used in V7A planning: content P90 ~466 words, P95 ~581 words; train titles are roughly 3–22 words.

## Strongest dataset-generation facts
- Exact normalized title+content overlap: **927 / 3,603 test rows = 25.73%** have an exact pair in train.
- No conflicting labels among those exact train pairs.
- Connected-component graph over exact normalized title/content: **11,525 components**.
- **5,419 train rows** are in non-singleton components.
- Same-content multi-title groups in train: **893**.
- **873 / 893 = 97.76%** of those groups have exactly one positive title.
- Positive mapping is almost deterministic: among **11,142 unique contents with a positive title**, **11,138 (99.96%)** have exactly one distinct positive headline.
- Distinct positive article→headline pairs after dedup: about **11,153**.

These facts strongly suggest the data-generating process is close to:

> article → one canonical headline, with some rows created by minimal factual perturbations of that canonical headline.

## Leaderboard trajectory
- V1: **0.93367**.
- V2: **0.94856**.
- V3: **0.94856** (OOF improved, LB did not).
- V4: **0.95681** — strongest proven breakthrough.
- V5: **0.95681** — four extra rescues, public tie; private effect unknown.
- V6A/B/C/D: not worth submitting; all fail-closed to V5 or produce zero active changes.
- Current observed Top-1: **0.98979**.

## Strongest causal evidence
V4 changed only **16 rows vs V2**:
- 15 × `1→0`
- 1 × `0→1`

and improved public score by **+0.00825** (0.94856 → 0.95681). This is the clearest evidence that precise structural/canonical corrections are valuable.

V3 changed 33 semantic fallback rows and improved semantic OOF, but public stayed exactly tied with V2. That is strong evidence that better generic semantic OOF is not automatically leaderboard-relevant.

## V6-series conclusion
- V6A: changing backbone to XLM-R gave weak residual discrimination but no safe tail.
- V6B: span-level counterfactual learning worked very well on paired corruptions (~94.7% pair ranking on scorable replacement pairs), but absolute row-risk deployment failed.
- V6C: relative challenger ranking idea was not fairly tested because the lexical generator had a critical IDF-filter bug; export cell also accidentally became Markdown.
- V6D: fixed the V6C IDF eligibility failure and introduced retrieval-first listwise design, but Stage-0 generator recall was still insufficient, so Transformer training was correctly skipped.

## New metric insight that changes future decision policy
Using V5 component-safe OOF aggregate confusion approximately:
- TN = **1242**
- FP = **195**
- FN = **381**
- TP = **12579**
- Macro F1 ≈ **0.894691**

For a `1→0` veto:
- one correct `FP→TN` changes Macro F1 by about **+0.000213**;
- one wrong `TP→FN` changes Macro F1 by about **−0.000152**.

Therefore the local break-even precision is only about **41.7%**, not 90%.

The V6 acceptance requirement of ≥90% precision was too conservative for the actual metric. However, existing V6A/V6B tails were still below even this ~42% break-even region, so this insight does **not** justify simply lowering old thresholds post hoc.

## Current bottleneck diagnosis
The pipeline has largely solved:
1. exact/repeated structural relations between examples (V2/V4), and
2. generic headline↔article semantic compatibility to a useful but not near-perfect level.

What remains is **canonical factual construction/binding**. Residual errors often attach the wrong entity, role, place, number, or polarity state to an otherwise correct topic.

The most promising unused supervision source is the near-deterministic **article → canonical headline** mapping itself, rather than explicit challenger generation.

## Current next version
**V7A — IndoBART Conditional Headline Likelihood Verifier**.

Key idea:
- fine-tune an Indonesian seq2seq model on deduplicated positive article→headline pairs;
- add contrastive ranking between canonical and same-content corrupted headlines;
- score the observed headline with teacher-forced conditional likelihood and worst-token surprisal;
- apply only low-coverage `1→0` interventions on V5-positive pure-fallback rows;
- choose intervention coverage by Macro F1 on a DESIGN split;
- then require positive transfer to a never-touched **20% prospective LOCK split** before any test submission.

This is the next experiment to implement/run. It has **not yet been run**.
