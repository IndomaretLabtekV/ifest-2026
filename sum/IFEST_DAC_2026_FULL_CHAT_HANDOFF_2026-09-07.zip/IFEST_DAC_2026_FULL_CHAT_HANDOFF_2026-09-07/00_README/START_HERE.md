# IFEST DAC 2026 — Full Chat Handoff

**Snapshot date:** 2026-09-07  
**Project:** IFEST 2026 Data Analysis Competition — Indonesian news headline vs article factual consistency classification  
**Current public score (our best):** 0.95681  
**Current observed Top-1 public score:** 0.98979  
**Current next research direction:** V7A — IndoBART Conditional Headline Likelihood Verifier  
**V7A status:** designed in detail, **not yet implemented/run** in this chat because the handoff request interrupted the implementation step.

This ZIP is intentionally **documentation-only**. It does **not** contain notebooks, model weights, raw result CSVs, prediction arrays, submissions, datasets, or raw competition data. It is meant to let another ChatGPT conversation continue the project without losing the experimental history, assumptions, failures, numbers, or decision logic developed here.

## Read in this order
1. `HANDOFF_SUMMARY.md` — executive state of the project.
2. `../02_DATASET/DATASET_PROFILE.md` — task/data facts and structural artifacts.
3. `../03_VALIDATION/VALIDATION_EVOLUTION.md` — how validation changed and what is trustworthy.
4. `../04_EXPERIMENTS/EXPERIMENT_MATRIX.md` — every version V1–V6D in one place.
5. `../06_RESEARCH/CORE_FINDINGS.md` — strongest scientific conclusions.
6. `../08_CURRENT_STATE/BOTTLENECK_DIAGNOSIS.md` — current diagnosis after Top-1 reached 0.98979.
7. `../08_CURRENT_STATE/V7A_DESIGN.md` — exact next-version architecture.
8. `../09_NEXT_ACTIONS/TODO_ORDERED.md` — what to do next, in order.
9. `NEXT_CHAT_PROMPT.md` — copy/paste bootstrap prompt for the next chat.

## Non-negotiable operational constraints
- Do **not** run training or experiments locally. Training is run by the user on Kaggle.
- Kaggle target environment is **T4 × 2**.
- Keep all future notebook experiments reproducible, component-safe, and fail-closed.
- Do not silently redesign an already-approved version during implementation.
- Do not submit a version merely because it exists. Submission decisions must be evidence-driven.
- Preserve V2/V4/V5 frozen decisions unless an explicitly new experiment is designed to challenge them.
- The next version must account for researcher-overfitting to the old folds; V7A introduces a new prospective LOCK split.

## Important rules ambiguity to re-check before V7A
Project notes contain a **rule-history ambiguity** around pretrained open-weight models: an earlier note recorded that a FAQ position changed, while the later guidebook audit used for V7A concluded pretrained open-weight models were allowed. Before training/submitting V7A, verify the **latest official guidebook/FAQ/organizer statement** and treat that as source of truth. Do not rely on this handoff alone for that rule.
