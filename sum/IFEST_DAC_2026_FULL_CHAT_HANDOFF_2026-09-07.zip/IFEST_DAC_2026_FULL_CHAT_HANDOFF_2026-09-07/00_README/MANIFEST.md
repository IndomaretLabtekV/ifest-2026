# Documentation Manifest

- `00_README/` — executive state, next-chat bootstrap, scope.
- `01_COMPETITION/` — task, metric, leaderboard context, rules/risk notes.
- `02_DATASET/` — dataset profile, structural graph, counterfactual mining, leakage concerns.
- `03_VALIDATION/` — evolution of CV, metric math, prospective LOCK protocol.
- `04_EXPERIMENTS/` — detailed history V1–V6D and experiment matrix.
- `05_SUBMISSIONS/` — public leaderboard/submission decisions.
- `06_RESEARCH/` — literature, core findings, rejected directions.
- `07_FAILURE_MODES/` — modeling, implementation, and validation failures.
- `08_CURRENT_STATE/` — champion, bottleneck diagnosis, exact V7A design/acceptance contract.
- `09_NEXT_ACTIONS/` — ordered to-do, Kaggle run checklist, decision tree.
- `10_ARTIFACT_REGISTRY/` — names/roles of notebooks and result bundles that existed, without including them.
- `11_DECISION_LOG/` — chronology, frozen decisions, what not to repeat.

No model/data/result artifacts are embedded in this ZIP.
