# Copy/Paste Prompt for a New Chat

You are continuing an IFEST 2026 Data Analysis Competition project. Read the full handoff ZIP first, especially `00_README/HANDOFF_SUMMARY.md`, `04_EXPERIMENTS/EXPERIMENT_MATRIX.md`, `06_RESEARCH/CORE_FINDINGS.md`, `08_CURRENT_STATE/BOTTLENECK_DIAGNOSIS.md`, and `08_CURRENT_STATE/V7A_DESIGN.md`.

Important state:
- Binary Indonesian headline-vs-article factual consistency; Macro F1.
- Train 14,397; test 3,603; positives 90.02%, negatives 9.98%.
- Structural artifacts are huge: 25.73% of test has exact normalized title+content overlap in train; 11,525 connected components; same-content groups are overwhelmingly one-canonical-positive.
- Our public trajectory: V1 0.93367 → V2 0.94856 → V4/V5 0.95681. Current observed Top-1 is 0.98979.
- V4 is strongest public-proven intervention: only 16 test changes gave +0.00825.
- V3 semantic OOF improvement did not transfer.
- V6A–D were research branches; none produced a new submission. V6B proved local corruption ranking can work, V6C had a generator bug, V6D Stage-0 generator recall still failed and skipped training.
- New metric audit shows a `1→0` veto only needs ~41.7% precision to break even on V5 OOF Macro F1, so the old 90% veto gate was unnecessarily conservative. Do not retroactively lower old thresholds because their actual tails were still below break-even.
- Current diagnosis: the best new information source is article→canonical-headline likelihood, not another challenger generator/backbone.
- Approved next design: **V7A IndoBART Conditional Headline Likelihood Verifier**. It uses a new prospective 80% DESIGN / 20% LOCK component split with seed 260907 to combat researcher-overfitting to the old CV folds. It trains on deduplicated positive article→headline mappings + real same-content contrastive negatives, scores mean NLL + top-2 worst token NLL, chooses low coverage by DESIGN Macro F1, then must survive LOCK untouched.
- V7A has been designed but not implemented/run yet.
- Kaggle target: T4×2. Do not run training locally. Future notebook should be <1MB if requested.
- Keep V2/V4 structural decisions and V5 rescues immutable unless a new explicitly-approved experiment says otherwise.
- Before V7A, verify the latest official rule on pretrained open-weight models because project notes contain conflicting historical rule signals.

When continuing, do not redesign V7A unless new evidence requires it. If asked to implement it, use the exact contracts in the handoff.
