# Competition Task and Rules Context

## Task
Given an Indonesian news `title` and `content`, predict whether the headline is factually consistent with the article.

- `1` = supported/consistent.
- `0` = factual mismatch.

The negatives are frequently **minimal factual corruptions**, not completely unrelated headlines. Typical changes include entity, organization, location, number, role, action, negation/polarity, and attachment/binding mistakes.

## Metric
**Macro F1** over the two classes.

This matters because class 0 is only ~10% of train. A correct negative correction can be more valuable than a wrong negative veto is costly, which is why the later break-even calculation matters.

## Leaderboard split
The later guidebook audit used in the project reported:
- public leaderboard: **30%** of test evaluation;
- private leaderboard: **70%**.

Therefore public LB is useful as an external signal but should not become a tuning set.

## Current public context
- Our best proven public score: **0.95681**.
- Current observed Top-1: **0.98979**.
- Public gap: ~**0.03298**.

The scale of this gap does not necessarily imply hundreds of wrong rows; with a ~1,081-row public subset, a difference of roughly 10–15 public decisions can plausibly create a score movement of this magnitude, depending on hidden class prevalence.

## Data/model-use rule caution
The project notes contain a historical ambiguity about pretrained/open-weight models:
- an earlier project note recorded that a FAQ stance changed;
- the later guidebook audit used for V7A concluded pretrained open-weight models were allowed.

**Action:** re-check the latest official organizer source immediately before running/submitting V7A. If the latest rules prohibit the planned checkpoint, V7A must not be run/submitted as designed.

## External data
The research branch has been intentionally designed around:
- competition train/test data;
- pretrained model weights only (subject to latest rule confirmation);
- no external labeled factual-consistency dataset;
- no external ground-truth retrieval.
