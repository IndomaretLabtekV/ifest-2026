# Leaderboard Context and Interpretation

## Public history
| Version | Public Macro F1 | Interpretation |
|---|---:|---|
| V1 | 0.93367 | Baseline proven |
| V2 | 0.94856 | Structural improvement transferred strongly |
| V3 | 0.94856 | Semantic OOF gain did not transfer |
| V4 | **0.95681** | Strongest causal improvement |
| V5 | **0.95681** | Four rescues; public tie, private unknown |
| V6A | not submitted | zero changes |
| V6B | not submitted | zero changes |
| V6C | not submitted | invalid/failed generator, zero changes |
| V6D | not submitted | Stage-0 fail, identical to V5 |

Current observed Top-1: **0.98979**.

## How to read V3 vs V5 ties
V3 changed **33 rows** vs V2. Under a 30% public subset, the probability that none of 33 random changes hit public is about `0.7^33 ≈ 7.7e-6`. So the exact public tie is meaningful evidence that the V3 semantic direction had little/no net public benefit.

V5 changed only **4 rows** vs V4. Probability all four happen to be private is `0.7^4 ≈ 24%`. Therefore V5's public tie is much weaker evidence; private gain/loss remains unknown.

## What Top-1 0.98979 changes
It increases the probability that:
1. the data-generation process is highly learnable/deterministic;
2. a stronger source of target-construction information exists beyond our current semantic verifier;
3. small but very accurate correction packages can still move the score materially.

It does **not** by itself prove a leak or justify public-LB chasing.
