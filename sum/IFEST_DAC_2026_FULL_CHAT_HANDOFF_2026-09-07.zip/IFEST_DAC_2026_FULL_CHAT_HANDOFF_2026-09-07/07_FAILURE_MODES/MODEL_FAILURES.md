# Modeling Failure Modes

## Whole-headline NLI dilution
A single wrong factual token can be overwhelmed by overall topical entailment. This explains many V1/V2/V6A residual false positives.

## Local-view underperformance
V2 local pooled branch underperformed global branch. Evidence windows can miss the decisive relation or overfocus on surface similarity.

## Absolute calibration mismatch
V6B learned relative canonical-vs-corrupted discrimination but deployed an absolute support threshold. Positive headlines often contain rare/weakly retrieved tokens that receive low support despite being correct.

## Min-aggregation false alarms
Using the weakest span as row risk makes one retrieval/model error dominate the whole headline.

## Open-set factual binding
V6C/D showed that identifying the correct factual alternative among many plausible article facts is much harder than choosing between a known canonical/corruption pair.

## Candidate-generation ceiling
If the canonical factual value is not in the candidate pool, no downstream ranker can recover it.

## Positive-diversity loss in V6A
Aggressive positive subsampling reduced legitimate positive diversity and likely hurt the specialist's ability to distinguish subtle false positives from unusual but valid headlines.

## Class-imbalance misunderstanding
Residual candidate prevalence can be ~1.2% negative. A model with decent ROC-AUC can still have unusable precision in the extreme tail.
