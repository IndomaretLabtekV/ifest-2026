# Implementation Bugs and Runtime Lessons

## V6B AMP/BCE crash
Error:
`torch.nn.functional.binary_cross_entropy and torch.nn.BCELoss are unsafe to autocast.`

Root cause:
- probability-domain BCE executed inside the autocast region.

Fix:
- autocast only around model forward;
- compute softmax, BCE, MIL, and pair loss in FP32 outside autocast.

This fix preserved the objective and was later statically verified.

## V6C lexical IDF eligibility bug
Root cause:
- `HIGH_IDF_THRESHOLD` used the 80th percentile of IDF over unique vocabulary types.
- due many hapax terms, the 80th percentile equaled max IDF (~9.8817).
- **0/431 canonical lexical spans** met the threshold.

Lesson:
- IDF may be a ranking feature, but hard eligibility thresholds over type-level quantiles are dangerous.

## V6C export block bug
The intended CSV/ZIP export block accidentally became a Markdown cell, so the executed notebook did not run it.

Lesson:
- static notebook handoff checks must verify cell types, not just source text.

## V6D GPU residency risk
During static verification, fold models were changed to CPU/disk snapshots and loaded one at a time for OOF/test scoring, preventing 3 fold models from staying resident on T4×2 simultaneously.

## General notebook delivery lessons
Before handoff:
- validate nbformat;
- compile every code cell;
- verify no training is run locally;
- confirm export cell is executable code;
- confirm outputs are not embedded if file-size constrained;
- audit AMP scope;
- audit GPU model lifetime/offloading;
- preserve frozen artifact alignment/hash guards where relevant.
