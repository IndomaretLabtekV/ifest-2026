# Validation and Research-Process Failure Modes

## Semantic OOF ≠ leaderboard utility
V3 is the canonical warning: semantic OOF increased materially but public did not move.

## Conditional metrics can hide coverage failure
V6B pair ranking looked excellent on 472 scorable replacements, but 129 insertion/deletion pairs were excluded from that diagnostic.

V6C also had a conditional top-1 metric on the tiny set where the canonical candidate was generated. Coverage-adjusted success was only ~3.33%.

Future metrics must include **generation/coverage-adjusted success**.

## Overly conservative precision gate
The V6 requirement of 90% precision ignored Macro-F1 class weighting. Break-even was ~41.7% for `1→0` vetoes. This caused safe abstention but also made promotion unnecessarily hard.

## Reusing the same folds too long
Even component-safe folds can become researcher-overfit if architecture decisions repeatedly use the same OOF residuals. V7A's prospective LOCK split addresses this.

## Public LB as a sparse external signal only
Do not fit per-row rules to public changes. V3/V4/V5 illustrate that public effects need causal interpretation, not blind optimization.
