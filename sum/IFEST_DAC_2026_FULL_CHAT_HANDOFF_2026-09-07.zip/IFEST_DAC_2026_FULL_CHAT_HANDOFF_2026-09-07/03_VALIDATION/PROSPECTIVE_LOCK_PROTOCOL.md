# Prospective LOCK Protocol for V7A

## Motivation
The seed-2026 component folds have been inspected repeatedly across many versions. Although they remain technically leakage-safe, repeated researcher decisions can overfit to their residual error surface.

## Split
Create connected components exactly as before, then make a one-time split with:
- `SEED_LOCK = 260907`
- **80% DESIGN**
- **20% LOCK**

Preserve approximate label prevalence and group isolation.

## DESIGN usage
Within DESIGN:
- 3-fold component-safe CV.
- train V7A models only on reference components.
- produce OOF generative scores.
- define the V7A risk exactly as precommitted.
- search only the fixed coverage grid.
- pick the coverage fraction that maximizes full Macro F1 delta vs frozen V5.

Fixed coverage grid over eligible V5-positive pure-fallback rows:
- 0%
- 0.2%
- 0.4%
- 0.6%
- 1.0%
- 1.5%
- 2.0%
- 3.0%

## Freeze
After DESIGN selection, freeze:
- architecture;
- risk formula;
- chosen coverage fraction;
- all structural locks;
- acceptance criteria.

## LOCK usage
Score LOCK with models that never trained on LOCK components. Apply the frozen coverage. Evaluate once.

If LOCK Macro F1 does not improve over V5, **reject V7A**. Do not tune and reopen LOCK.

## Why coverage, not probability threshold
Final seq2seq likelihood scale can shift across folds/final seeds. A rank/coverage fraction is more stable than an absolute NLL threshold.
