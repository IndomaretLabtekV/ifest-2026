# Macro F1: Utility and Break-Even Analysis

## V5 OOF aggregate confusion used in the later audit
Approximate component-safe OOF confusion:
- TN = **1242**
- FP = **195**
- FN = **381**
- TP = **12579**
- Macro F1 ≈ **0.894691**

## Marginal effect of `1→0` veto
For the current confusion regime:
- correct veto (`FP→TN`): ~**+0.000213 Macro F1**.
- wrong veto (`TP→FN`): ~**−0.000152 Macro F1**.

Break-even precision is approximately:

`0.000213*p - 0.000152*(1-p) > 0`

which gives roughly:

> **p > 41.7%**

For low-to-moderate batches of corrections, the break-even region remains around 42%.

## Marginal effect of `0→1` rescue
The opposite direction needs approximately:

> **58.3%** correct

to break even locally.

## Consequence
The old V6 requirement of **≥90% veto precision** was not metric-aligned. It was a safety heuristic, not a mathematically justified threshold.

However, do not retroactively lower V6 thresholds:
- V6A and V6B extreme-tail precision was mostly ~5–20%, still below break-even.
- Cross-fitted stacks did not produce stable positive Macro F1 transfer.

## Future decision rule
Primary selection criterion should be **actual cross-fitted Macro F1 delta**, with precision used only as a safety guardrail.

V7A therefore uses a 50% LOCK precision guard (above the ~42% break-even) rather than 90%, while still requiring positive DESIGN/LOCK Macro F1.
