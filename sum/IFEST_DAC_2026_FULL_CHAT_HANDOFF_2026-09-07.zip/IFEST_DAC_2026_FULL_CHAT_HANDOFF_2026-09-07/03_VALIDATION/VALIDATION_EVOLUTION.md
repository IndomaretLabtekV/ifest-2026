# Validation Evolution

## Phase 1 — strict semantic/component CV
V1/V2 used 3-fold component-safe StratifiedGroupKFold (seed 2026). This prevented exact title/content relatives crossing folds.

V1 semantic/meta OOF was around 0.84. V2's semantic OOF was not better, yet V2 improved public substantially. This was the first sign that OOF for generic semantics was not fully aligned with the competition's structural data-generation process.

## Phase 2 — structural pseudo-competition
V4 used train-derived pseudo competition simulations to validate exact same-content canonical matching before touching test groups.

V4 had extremely strong pseudo behavior and then improved public, validating this methodology.

## Phase 3 — conservative rescue/veto cross-fitting
V5–V6 used:
- frozen upstream structural decisions;
- candidate-specific evaluation populations;
- thresholds selected from other folds;
- high-precision acceptance gates;
- pseudo competitions and component Macro F1.

This prevented destructive changes, but the 90% precision requirement later proved too conservative for Macro F1.

## Phase 4 — Stage-0 generator gating
V6D made candidate-generation recall an independent pre-training gate. Because generator recall was inadequate, Transformer training was skipped. This was methodologically correct and saved GPU time.

## Phase 5 — prospective LOCK for V7A
The old seed-2026 folds have now indirectly influenced many design decisions. V7A therefore creates a one-time new component split:
- seed: **260907**
- **80% DESIGN**
- **20% LOCK**

Within DESIGN, use 3-fold component CV for model/coverage selection.

LOCK labels must not influence:
- architecture;
- risk definition;
- training;
- coverage fraction;
- thresholds.

After DESIGN is frozen, evaluate LOCK once. If it fails, V7A is rejected rather than retuned.
